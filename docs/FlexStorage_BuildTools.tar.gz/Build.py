#!/usr/bin/env python
#-*- coding:utf-8 -*-

import os
import sys

sys_version="centos7.1"

def make_dir(path,dir_name):

    abs_path=os.path.abspath(path)
    new_path=abs_path+"/"+dir_name
    if not os.path.exists(new_path):
	os.mkdir(new_path)
    cmd="rm -rf "+new_path+"/*"
    print "[make_dir]", cmd
    os.system(cmd)

def Build_Directories():

    make_dir(".","build")
    make_dir(".","docs")
    make_dir(".","utils")
    make_dir(".","rpms")
    make_dir("./build","calamari")
    make_dir("./build","zabbix")
    

def copy_files(src,files,dest):

    abs_src=os.path.abspath(src)
    abs_dest=os.path.abspath(dest)
    
    cmd="cp -rf "+abs_src+"/"+files+" "+abs_dest+"/"
    print "[copy_files]", cmd
    os.system(cmd)

def Get_Files():

    copy_files("./git/docs/release","*","./docs")

    copy_files("./git/installations/build/","setup_calamari.sh","./build/calamari")
    copy_files("./git/installations/build/","setup_ceph.py","./build")
    copy_files("./git/installations/build/","setup.sh","./build")

    copy_files("./git/installations/fabric/utils","*","./utils")

    copy_files("./git/installations/zabbix","*","./build/zabbix")

    copy_files("./git/packages/release","*.rpm","./rpms")
    path="./git/packages/rpm/%s/" % (sys_version)
    copy_files(path,"*.rpm","./rpms")

def Build_FlexStorage_Rpm():

    if not os.path.isfile("FlexStorage.spec") or not os.path.isfile("Makefile"):
	sys.exit(0)
    os.system("rm -rf rpmbuild")
    os.system("rm -rf ./rpms/repodata")
    os.system("createrepo ./rpms/")
    os.system("tar cvzf build/ceph-rpms.tgz -C rpms/ .")
    os.system("tar cvzf build.tar.gz build utils docs")
    os.system("make rpm")
    os.system("rm -f ./build.tar.gz")
    os.system("rm -f ./build/ceph-rpms.tg")

if __name__ == '__main__':
    Build_Directories()
    Get_Files()
    Build_FlexStorage_Rpm()
