#!/usr/bin/env python
#-*- coding:utf-8 -*-

import sys
import os
import getopt

Flag_ceph=0
Flag_calamari_server=0
Flag_calamari_client=0
Flag_diamond=0

path="git"

def Set_Flags():

    global Flag_ceph,Flag_calamari_server,Flag_calamari_client
    Flag_ceph=1
    Flag_calamari_server=0
    Flag_calamari_client=1
    Flag_diamond=0
def Create_Path():

    os.system("if [ ! -d git ];then mkdir git;fi")
    os.system("rm -rf git/*")
    os.chdir("./git")
"""
def usage():

    print 'usage1:python Compile.py --ceph=0 --calamari-server=0 --calamari-client=1'
    print 'usage2:python Compile.py -c 0 -a 0 -i 1'
def Get_Flags():
    global Flag_ceph,Flag_calamari_server,Flag_calamari_client
    options,args=getopt.getopt(sys.argv[1:],"hc:a:i:",["help","ceph=","calamari-server=","calamari-client="])
    for option, value in options:
        #print "options", options
        if option in ["-h","--help"]:
	    usage()
	    exit(0)
        elif option in ["-c","--ceph"]:
	    Flag_ceph=value
            #print "ceph,value=", value
        elif option  in ["-a","--calamari-server"]:
	    Flag_calamari_server=value
            #print "calamari-server,value=", value
        elif option in ["-i","--calamari-client"]:
	    Flag_calamari_client=value
            #print "calamari-client,value=", Flag_calamari_client
"""
def Clone_Repo():

    os.system('git clone http://172.16.164.211/flexstorage/calamari')
    os.system('git clone http://172.16.164.211/flexstorage/calamari-clients')
    os.system('git clone http://172.16.164.211/flexstorage/ceph')
    os.system('git clone http://172.16.164.211/flexstorage/diamond')
    os.system('git clone http://172.16.164.211/flexstorage/docs')
    os.system('git clone http://172.16.164.211/flexstorage/installations')
    os.system('git clone http://172.16.164.211/flexstorage/packages')
    

def compile_calamari_server():

    #os.system('cd ./calamari;git checkout -b;cd ..')
    os.system('rm -rf ./calamari/rpmbuild')
    os.system('cd ./calamari;sh build-rpm.sh;cd ..')
    os.system('rm -f ./packages/rpm/release/calamari-server-*.rpm')
    os.system('cp ./calamari/rpmbuild/RPMS/x86_64/calamari-server*.rpm ./packages/release/')

def compile_calamari_client():

    print "[compile_calamari_client]"
    os.system('cd ./calamari-clients;git checkout -b develop-master origin/develop-master;cd ..')
    os.system('rm -rf ./rpmbuild')
    os.system('cd ./calamari-clients;sh compile.sh;cd ..')
    os.system('rm -f ./packages/release/calamari-clients-*.rpm')
    os.system('cp ./rpmbuild/RPMS/x86_64/calamari-clients-*.rpm ./packages/release/')

def compile_ceph():

    print "[compile_ceph]"
    tag_name="v0.94.6-1"
    os.system('cd ./ceph;git checkout -b develop-1 origin/develop-1;git tag %s;cd ..' % (tag_name))
    os.system('cd ./ceph;sh compile.sh;cd ..')
    #Delete ceph rpms checkout from git.
    os.system('cd ./packages/release;rm -f `ls | grep "\-0.94.*"`')
    #Copy new rpms to building environment.
    os.system('cp ./ceph/RPMS/x86_64/*.rpm ./packages/release/')

def compile_diamond():

    pass


def Start_Compling():

    #print Flag_ceph, Flag_calamari_server, Flag_calamari_client
    if int(Flag_calamari_server)==1:
	#print "Flag_calamari_server==1"
	compile_calamari_server()
    if int(Flag_calamari_client)==1:
	#print "Flag_calamari_client==1"
	compile_calamari_client()
    if int(Flag_ceph)==1:
	#print "Flag_ceph==1"
	compile_ceph()
    if int(Flag_diamond)==1:
	compile_diamond()

if __name__=='__main__':
    Create_Path()
    Set_Flags()
    Clone_Repo()
    Start_Compling()
